import os
import shutil
import zipfile
import tarfile
import gzip
import bz2
import lzma
import py7zr
import patoolib

SUPPORTED_EXTENSIONS = [
    ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z", ".rar", ".tar.gz", ".tar.bz2", ".tar.xz"
]

def extract_file(filepath, extract_to):
    filename = os.path.basename(filepath)
    name, ext = os.path.splitext(filename)

    if filename.endswith(".tar.gz"):
        ext = ".tar.gz"
    elif filename.endswith(".tar.bz2"):
        ext = ".tar.bz2"
    elif filename.endswith(".tar.xz"):
        ext = ".tar.xz"

    print(f"[+] Extracting: {filepath}")

    try:
        if ext == ".zip":
            with zipfile.ZipFile(filepath, 'r') as zip_ref:
                zip_ref.extractall(extract_to)
        elif ext in [".tar", ".tar.gz", ".tar.bz2", ".tar.xz"]:
            with tarfile.open(filepath, 'r:*') as tar:
                tar.extractall(path=extract_to)
        elif ext == ".gz":
            with gzip.open(filepath, 'rb') as f_in:
                with open(os.path.join(extract_to, name), 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif ext == ".bz2":
            with bz2.open(filepath, 'rb') as f_in:
                with open(os.path.join(extract_to, name), 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif ext == ".xz":
            with lzma.open(filepath, 'rb') as f_in:
                with open(os.path.join(extract_to, name), 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif ext == ".7z":
            with py7zr.SevenZipFile(filepath, mode='r') as z:
                z.extractall(path=extract_to)
        elif ext == ".rar":
            patoolib.extract_archive(filepath, outdir=extract_to)
        else:
            print(f"[!] Unsupported file type: {ext}")
            return False
        return True
    except Exception as e:
        print(f"[!] Failed to extract {filepath}: {e}")
        return False

def is_archive(filename):
    return any(filename.endswith(ext) for ext in SUPPORTED_EXTENSIONS)

def recursive_extract(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            full_path = os.path.join(root, file)
            if is_archive(file):
                extract_folder = os.path.join(root, f"{file}_extracted")
                os.makedirs(extract_folder, exist_ok=True)
                if extract_file(full_path, extract_folder):
                    recursive_extract(extract_folder)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="재귀적 압축 해제기")
    parser.add_argument("path", help="대상 폴더 또는 압축 파일 경로")
    args = parser.parse_args()

    input_path = args.path

    if os.path.isfile(input_path) and is_archive(input_path):
        extract_dir = input_path + "_extracted"
        os.makedirs(extract_dir, exist_ok=True)
        if extract_file(input_path, extract_dir):
            recursive_extract(extract_dir)
    elif os.path.isdir(input_path):
        recursive_extract(input_path)
    else:
        print("[!] 유효한 압축 파일 또는 디렉터리를 입력하세요.")
